# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.

import boto3
import os
import re
from botocore.auth import SigV4Auth
from botocore.credentials import Credentials
from sagemaker.partner_app.auth_requests import RequestsAuth
from sagemaker.partner_app.utils import get_signed_request

SERVICE_NAME = 'sagemaker'
AWS_PARTNER_APP_ARN_REGEX = "arn:aws[a-z\-]*:sagemaker:[a-z0-9\-]*:[0-9]{12}:partner-app\/.*"

class PartnerAppAuthProvider:
    def __init__(self, credentials: Credentials = None):
        self.app_arn = os.getenv("AWS_PARTNER_APP_ARN")
        if self.app_arn is None:
            raise ValueError("Must specify a valid AWS_PARTNER_APP_ARN environment variable")
        
        app_arn_regex_match = re.search(AWS_PARTNER_APP_ARN_REGEX, self.app_arn)
        if app_arn_regex_match is None:
            raise ValueError("Must specify a valid AWS_PARTNER_APP_ARN environment variable")
        
        split_arn = self.app_arn.split(':')
        self.region = split_arn[3]

        self.credentials = credentials if credentials is not None else boto3.Session().get_credentials()
        self.sigv4 = SigV4Auth(self.credentials, SERVICE_NAME, self.region)

    def get_signed_request(self, url: str, method: str, headers: dict, body: object) -> dict:
        return get_signed_request(
            sigv4=self.sigv4,
            app_arn=self.app_arn,
            url=url,
            method=method,
            headers=headers,
            body=body
        )

    def get_auth(self) -> RequestsAuth:
        """Returns the callback class (RequestsAuth) used for generating the SigV4 header.
        
        Returns:
            RequestsAuth: Callback Object which will calculate the header just before request submission.
        """

        return RequestsAuth(self.sigv4, os.environ['AWS_PARTNER_APP_ARN'])
