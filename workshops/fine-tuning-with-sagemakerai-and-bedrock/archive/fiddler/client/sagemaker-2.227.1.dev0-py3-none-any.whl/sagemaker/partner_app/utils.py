from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
from hashlib import sha256
import functools

PAYLOAD_BUFFER = 1024 * 1024
EMPTY_SHA256_HASH = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
UNSIGNED_PAYLOAD = 'UNSIGNED-PAYLOAD'

def get_signed_request(sigv4: SigV4Auth, app_arn: str, url: str, method: str, headers: dict, body: object):
    # Move API key to X-Amz-Partner-App-Authorization
    if 'Authorization' in headers:
        headers['X-Amz-Partner-App-Authorization'] = headers['Authorization']
    # App Arn
    headers['X-Mlapp-Sm-App-Server-Arn'] = app_arn
    # IAM Action
    headers['X-Amz-Target'] = 'SageMaker.CallPartnerAppApi'
    # Body
    headers['X-Amz-Content-SHA256'] = get_body_header(body)
    # Connection header is excluded from server-side signature calculation
    connection_header = headers['Connection'] if 'Connection' in headers else None
    if 'Connection' in headers:
        del headers['Connection']
    # Spaces are encoded as %20
    if method == 'GET' or method == 'DEL':
        url = url.replace('+', '%20')

    # Calculate SigV4 header
    aws_request = AWSRequest(
        method=method,
        url=url,
        headers=headers,
        data=body,
    )
    sigv4.add_auth(aws_request)

    # Reassemble headers
    final_headers = dict(aws_request.headers.items())
    if connection_header is not None:
        final_headers["Connection"] = connection_header

    return (url, final_headers)

def get_body_header(body: object):
    if body and hasattr(body, 'seek'):
        position = body.tell()
        read_chunksize = functools.partial(
            body.read, PAYLOAD_BUFFER
        )
        checksum = sha256()
        for chunk in iter(read_chunksize, b''):
            checksum.update(chunk)
        hex_checksum = checksum.hexdigest()
        body.seek(position)
        return hex_checksum
    elif type(body) is not bytes and body is not None:
        # Body is of a class we don't recognize, so don't sign the payload
        return UNSIGNED_PAYLOAD
    elif body:
        # The request serialization has ensured that
        # request.body is a bytes() type.
        return sha256(body).hexdigest()
    else:
        # Body is None
        return EMPTY_SHA256_HASH