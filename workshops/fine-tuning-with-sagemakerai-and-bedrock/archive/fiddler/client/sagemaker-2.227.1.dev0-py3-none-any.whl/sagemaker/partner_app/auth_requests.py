# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.

from botocore.auth import SigV4Auth
from requests.auth import AuthBase
from requests.models import PreparedRequest
from sagemaker.partner_app.utils import get_signed_request

SERVICE_NAME = 'sagemaker'


class RequestsAuth(AuthBase):
    def __init__(self, sigv4: SigV4Auth, app_arn: str):
        self.sigv4 = sigv4
        self.app_arn = app_arn

    def __call__(self, request: PreparedRequest) -> PreparedRequest:
        url, signed_headers = get_signed_request(
            sigv4=self.sigv4,
            app_arn=self.app_arn,
            url=request.url,
            method=request.method,
            headers=request.headers,
            body=request.body
        )
        request.url = url
        request.headers.update(signed_headers)

        return request


